<?php

defined('_JEXEC') || die;

use Joomla\CMS\Application\CMSApplication;
use Joomla\CMS\Application\SiteApplication;
use Joomla\CMS\Log\Log;
use Joomla\CMS\Plugin\CMSPlugin;

class plgSystemSortbyfield extends CMSPlugin
{
	/** @var CMSApplication */
	public $app;

	/** @inheritDoc */
	public function __construct(&$subject, $config = [])
	{
		parent::__construct($subject, $config);

		require_once 'library/buffer.php';
	}

	/**
	 * Runs when Joomla is initializing its application.
	 *
	 * This is used to patch Joomla's Articles modeil in-memory
	 *
	 * @noinspection PhpUnused
	 *
	 * @return  void
	 *
	 * @since        1.0.0
	 */
	public function onAfterInitialise(): void
	{
		// Only applies to the frontend application
		if (!is_object($this->app) || !($this->app instanceof SiteApplication))
		{
			return;
		}

		// Load our language strings
		$this->loadLanguage();

		// Make sure the class isn't loaded yet
		if (class_exists('ContentModelArticles', false))
		{
			Log::add('SortByFields: Cannot initialize. ContentModelArticles has already been loaded. Please reorder this plugin to be the first one loaded.', Log::CRITICAL);

			return;
		}

		// In-memory patching of Joomla's ContentModelArticles class
		$source     = JPATH_SITE . '/components/com_content/models/articles.php';
		$foobar     = <<< PHP
		// Import the appropriate plugin group.
		\JPluginHelper::importPlugin('content');

		// Get the dispatcher.
		\$dispatcher = \JEventDispatcher::getInstance();

		// Trigger the form preparation event.
		\$dispatcher->trigger('onComContentArticlesGetListQuery', [&\$query]);

		return \$query;
PHP;
		$phpContent = file_get_contents($source);
		$phpContent = str_replace('return $query;', $foobar, $phpContent);

		$bufferLocation = 'sortbyfield://plgSystemMailmagicBufferMail.php';

		file_put_contents($bufferLocation, $phpContent);

		require_once $bufferLocation;
	}

	public function onComContentArticlesGetListQuery(JDatabaseQuery &$query)
	{
		echo "<pre>" . $query . "</pre>";
	}
}